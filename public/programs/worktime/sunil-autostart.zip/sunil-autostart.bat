@echo off
rem Sunil-time mini window: start with Windows (run once)
set "URL=https://claude.ai/artifact/V5Toqsg9Zr9ohWGC9KdxZS#mini"
set "CH=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if not exist "%CH%" set "CH=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
if not exist "%CH%" set "CH=%LocalAppData%\Google\Chrome\Application\chrome.exe"
if not exist "%CH%" (
  echo Chrome not found. Please install Google Chrome first.
  pause
  exit /b 1
)
powershell -NoProfile -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Startup')+'\SunilTime.lnk'); $s.TargetPath='%CH%'; $s.Arguments='--app=\"%URL%\" --window-size=340,300'; $s.Save()"
echo Done. The mini window will open every time Windows starts.
echo To turn it off: Win+R, type shell:startup, delete SunilTime.
start "" "%CH%" --app="%URL%" --window-size=340,300
pause
