﻿# 영상받기: 유튜브·인스타그램 주소를 붙여 넣고 [받기]를 누르면 원본 화질로 저장 (yt-dlp 사용)
# 사이트(ai-leehyun.vercel.app/programs/downloader)의 [내 PC로 받기]는 aileehyun-dl: 주소로 이 창을 열어요.
param([string]$Link = '')
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$Root   = Split-Path -Parent $MyInvocation.MyCommand.Path
$Bin    = Join-Path $Root 'bin'
$YtDlp  = Join-Path $Bin 'yt-dlp.exe'
$FFmpeg = Join-Path $Bin 'ffmpeg.exe'
$Tmp    = Join-Path $env:TEMP 'yeongsang-batgi'
$CfgDir = Join-Path $env:APPDATA '영상받기'
$Cfg    = Join-Path $CfgDir 'settings.json'
$Out    = Join-Path ([Environment]::GetFolderPath('UserProfile')) 'Downloads\영상받기'
New-Item -ItemType Directory -Force -Path $Bin, $Tmp, $CfgDir | Out-Null
try { $saved = (Get-Content $Cfg -Raw -Encoding UTF8 | ConvertFrom-Json).out; if ($saved) { $Out = $saved } } catch {}
New-Item -ItemType Directory -Force -Path $Out | Out-Null
function Save-Cfg { @{ out = $Out } | ConvertTo-Json | Set-Content -Path $Cfg -Encoding UTF8 }

# 사이트 버튼 연동: aileehyun-dl: 주소를 이 프로그램에 연결 (내 계정에만, 관리자 권한 없이). 폴더를 옮겨도 열 때마다 다시 연결.
try {
  $k = 'HKCU:\Software\Classes\aileehyun-dl'
  New-Item -Path "$k\shell\open\command" -Force | Out-Null
  Set-ItemProperty -Path $k -Name '(default)' -Value 'URL:영상받기'
  Set-ItemProperty -Path $k -Name 'URL Protocol' -Value ''
  $me = $MyInvocation.MyCommand.Path
  Set-ItemProperty -Path "$k\shell\open\command" -Name '(default)' -Value ('powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File "' + $me + '" "%1"')
} catch {}

# aileehyun-dl://get?u=<주소>&mp3=1 → 주소 목록
$FromSite = @(); $SiteMp3 = $false
if ($Link -match '^aileehyun-dl:') {
  foreach ($part in ($Link -replace '^aileehyun-dl:/*(get)?\??', '').Split('&')) {
    $kv = $part.Split('=', 2)
    if ($kv.Count -eq 2) {
      $v = [System.Uri]::UnescapeDataString($kv[1].Replace('+', ' '))
      if ($kv[0] -eq 'u') { $FromSite += ($v -split '\s+' | Where-Object { $_ -match '^https?://' }) }
      if ($kv[0] -eq 'mp3' -and $v -eq '1') { $SiteMp3 = $true }
    }
  }
}

$font  = New-Object System.Drawing.Font('Malgun Gothic', 11)
$small = New-Object System.Drawing.Font('Malgun Gothic', 9)

$form = New-Object System.Windows.Forms.Form
$form.Text = '영상받기 · 유튜브 / 인스타그램'
$form.Size = New-Object System.Drawing.Size(640, 580)
$form.StartPosition = 'CenterScreen'
$form.Font = $font
$form.BackColor = [System.Drawing.Color]::FromArgb(238, 240, 242)

$lbl = New-Object System.Windows.Forms.Label
$lbl.Text = '영상 주소를 붙여 넣으세요 (여러 개면 한 줄에 하나씩)'
$lbl.Location = New-Object System.Drawing.Point(16, 14)
$lbl.AutoSize = $true
$form.Controls.Add($lbl)

$box = New-Object System.Windows.Forms.TextBox
$box.Multiline = $true
$box.ScrollBars = 'Vertical'
$box.Location = New-Object System.Drawing.Point(16, 42)
$box.Size = New-Object System.Drawing.Size(592, 110)
$box.Anchor = 'Top, Left, Right'
$form.Controls.Add($box)

$mp3 = New-Object System.Windows.Forms.CheckBox
$mp3.Text = '소리만 (mp3)'
$mp3.Location = New-Object System.Drawing.Point(16, 162)
$mp3.AutoSize = $true
$form.Controls.Add($mp3)

$login = New-Object System.Windows.Forms.CheckBox
$login.Text = '인스타 로그인 필요 (엣지 로그인 사용)'
$login.Location = New-Object System.Drawing.Point(160, 162)
$login.AutoSize = $true
$form.Controls.Add($login)

$go = New-Object System.Windows.Forms.Button
$go.Text = '받기'
$go.Location = New-Object System.Drawing.Point(16, 196)
$go.Size = New-Object System.Drawing.Size(140, 44)
$go.BackColor = [System.Drawing.Color]::FromArgb(36, 39, 44)
$go.ForeColor = [System.Drawing.Color]::White
$go.FlatStyle = 'Flat'
$form.Controls.Add($go)

$open = New-Object System.Windows.Forms.Button
$open.Text = '저장 폴더 열기'
$open.Location = New-Object System.Drawing.Point(166, 196)
$open.Size = New-Object System.Drawing.Size(150, 44)
$form.Controls.Add($open)

$cfgBtn = New-Object System.Windows.Forms.Button
$cfgBtn.Text = '⚙ 설정'
$cfgBtn.Location = New-Object System.Drawing.Point(506, 196)
$cfgBtn.Size = New-Object System.Drawing.Size(102, 44)
$form.Controls.Add($cfgBtn)

$where = New-Object System.Windows.Forms.Label
$where.Font = $small
$where.ForeColor = [System.Drawing.Color]::FromArgb(95, 102, 112)
$where.Location = New-Object System.Drawing.Point(16, 244)
$where.Size = New-Object System.Drawing.Size(592, 18)
$where.Anchor = 'Top, Left, Right'
$where.Text = '저장 폴더: ' + $Out
$form.Controls.Add($where)

$upd = New-Object System.Windows.Forms.Button
$upd.Text = '프로그램 업데이트'
$upd.Location = New-Object System.Drawing.Point(326, 196)
$upd.Size = New-Object System.Drawing.Size(170, 44)
$form.Controls.Add($upd)

$status = New-Object System.Windows.Forms.Label
$status.Location = New-Object System.Drawing.Point(16, 266)
$status.Size = New-Object System.Drawing.Size(592, 26)
$status.Anchor = 'Top, Left, Right'
$form.Controls.Add($status)

$bar = New-Object System.Windows.Forms.ProgressBar
$bar.Location = New-Object System.Drawing.Point(16, 294)
$bar.Size = New-Object System.Drawing.Size(592, 14)
$bar.Anchor = 'Top, Left, Right'
$form.Controls.Add($bar)

$log = New-Object System.Windows.Forms.TextBox
$log.Multiline = $true
$log.ReadOnly = $true
$log.ScrollBars = 'Vertical'
$log.Font = $small
$log.Location = New-Object System.Drawing.Point(16, 318)
$log.Size = New-Object System.Drawing.Size(592, 186)
$log.Anchor = 'Top, Bottom, Left, Right'
$form.Controls.Add($log)

function Say($t) { $status.Text = $t; [System.Windows.Forms.Application]::DoEvents() }
function Log($t) { $log.AppendText($t + "`r`n") }

# 처음 한 번: yt-dlp와 ffmpeg 내려받기
function Ensure-Tools {
  $wc = New-Object System.Net.WebClient
  if (-not (Test-Path $YtDlp)) {
    Say '처음 한 번 준비 중… (yt-dlp 내려받는 중)'
    $wc.DownloadFile('https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp.exe', $YtDlp)
  }
  if (-not (Test-Path $FFmpeg)) {
    Say '처음 한 번 준비 중… (ffmpeg 내려받는 중, 1~2분 걸려요)'
    $zip = Join-Path $Tmp 'ffmpeg.zip'
    $wc.DownloadFile('https://github.com/yt-dlp/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip', $zip)
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $z = [System.IO.Compression.ZipFile]::OpenRead($zip)
    try {
      foreach ($e in $z.Entries) {
        if ($e.Name -eq 'ffmpeg.exe' -or $e.Name -eq 'ffprobe.exe') {
          [System.IO.Compression.ZipFileExtensions]::ExtractToFile($e, (Join-Path $Bin $e.Name), $true)
        }
      }
    } finally { $z.Dispose() }
    Remove-Item $zip -Force -ErrorAction SilentlyContinue
  }
  Say '준비 완료. 주소를 붙여 넣고 [받기]를 누르세요.'
}

$script:proc = $null
$script:outFile = Join-Path $Tmp 'out.txt'
$script:errFile = Join-Path $Tmp 'err.txt'
$script:seen = 0

function Start-Job2([string[]]$argsList, [string]$label) {
  Remove-Item $script:outFile, $script:errFile -Force -ErrorAction SilentlyContinue
  $script:seen = 0
  $q = $argsList | ForEach-Object { if ($_ -match '[\s"]') { '"' + ($_ -replace '"', '\"') + '"' } else { $_ } }
  $script:proc = Start-Process -FilePath $YtDlp -ArgumentList ($q -join ' ') -WindowStyle Hidden -PassThru `
    -RedirectStandardOutput $script:outFile -RedirectStandardError $script:errFile
  $go.Enabled = $false; $upd.Enabled = $false
  $bar.Value = 0
  Say $label
  $timer.Start()
}

$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 500
$timer.Add_Tick({
  if (Test-Path $script:outFile) {
    $lines = @(Get-Content $script:outFile -Encoding UTF8 -ErrorAction SilentlyContinue)
    for ($i = $script:seen; $i -lt $lines.Count; $i++) {
      $l = $lines[$i]
      if ($l -match '\[download\]\s+([\d\.]+)%') {
        $p = [int][double]$Matches[1]; if ($p -ge 0 -and $p -le 100) { $bar.Value = $p }
        $status.Text = '받는 중… ' + $l.Replace('[download]', '').Trim()
      } elseif ($l -match '^\[download\] Destination: (.+)$') {
        Log ('▶ ' + (Split-Path -Leaf $Matches[1]))
      } elseif ($l -match 'has already been downloaded') {
        Log '· 이미 받은 영상이라 건너뛰었어요'
      } elseif ($l -match '^\[(Merger|ExtractAudio)\]') {
        $status.Text = '파일 합치는 중…'
      }
    }
    $script:seen = $lines.Count
  }
  if ($script:proc -and $script:proc.HasExited) {
    $timer.Stop()
    $err = ''
    if (Test-Path $script:errFile) { $err = (Get-Content $script:errFile -Encoding UTF8 -ErrorAction SilentlyContinue | Where-Object { $_ -match 'ERROR' }) -join "`r`n" }
    if ($script:proc.ExitCode -eq 0) {
      $bar.Value = 100
      Say ('끝났어요. 저장 위치: ' + $Out)
      $box.Text = ''
    } else {
      Say '일부를 못 받았어요. 아래 내용을 확인하세요.'
      if ($err) { Log $err }
      if ($err -match 'login|cookies|rate-limit|Sign in') { Log '→ 인스타 비공개·로그인 필요 영상이면 [인스타 로그인 필요]를 켜고 엣지 창을 모두 닫은 뒤 다시 받아 보세요.' }
      Log '→ 계속 안 되면 [프로그램 업데이트]를 눌러 보세요. 사이트가 바뀌면 업데이트로 해결되는 경우가 많아요.'
    }
    $go.Enabled = $true; $upd.Enabled = $true
    $script:proc = $null
  }
})

$go.Add_Click({
  $urls = @($box.Lines | ForEach-Object { $_.Trim() } | Where-Object { $_ -match '^https?://' })
  if ($urls.Count -eq 0) { Say 'http로 시작하는 주소를 넣어 주세요.'; return }
  $list = Join-Path $Tmp 'urls.txt'
  [System.IO.File]::WriteAllLines($list, $urls)
  $a = @('--newline', '--no-colors', '--encoding', 'utf-8', '--ffmpeg-location', $Bin, '-P', $Out,
         '-o', '%(extractor_key)s/%(uploader,channel|unknown).40s/%(upload_date>%Y-%m-%d|)s %(title).70B [%(id)s].%(ext)s',
         '--windows-filenames', '--no-mtime', '-a', $list)
  if ($mp3.Checked) { $a += @('-x', '--audio-format', 'mp3') }
  else { $a += @('-f', 'bv*+ba/b', '--merge-output-format', 'mp4', '-S', 'vcodec:h264,res,acodec:m4a') }
  if ($login.Checked) { $a += @('--cookies-from-browser', 'edge') }
  Log ('— ' + (Get-Date -Format 'HH:mm') + ' ' + $urls.Count + '개 받기 시작')
  Start-Job2 $a ('받기 시작… (' + $urls.Count + '개)')
})

$open.Add_Click({ Start-Process explorer.exe $Out })
$cfgBtn.Add_Click({
  $d = New-Object System.Windows.Forms.FolderBrowserDialog
  $d.Description = '영상을 저장할 폴더를 고르세요'
  $d.SelectedPath = $Out
  if ($d.ShowDialog($form) -eq 'OK' -and $d.SelectedPath) {
    $script:Out = $d.SelectedPath
    Save-Cfg
    $where.Text = '저장 폴더: ' + $Out
    Log ('— 저장 폴더를 바꿨어요: ' + $Out)
  }
})
$upd.Add_Click({ Log '— 프로그램 업데이트'; Start-Job2 @('-U') '업데이트 중…' })

# 창이 열릴 때 클립보드에 주소가 있으면 미리 넣어 두기
$form.Add_Shown({
  try {
    Ensure-Tools
  } catch {
    Say '준비 중 오류가 났어요. 인터넷 연결을 확인하고 다시 열어 주세요.'
    Log $_.Exception.Message
    $go.Enabled = $false
  }
  if ($FromSite.Count -gt 0) {
    $box.Text = ($FromSite -join "`r`n")
    $mp3.Checked = $SiteMp3
    Log '— 사이트에서 보낸 주소를 받았어요'
    if ($go.Enabled) { $go.PerformClick() }
    return
  }
  try {
    $c = [System.Windows.Forms.Clipboard]::GetText()
    if ($c -match '^https?://\S*(youtu|instagram)') { $box.Text = $c.Trim() }
  } catch {}
  $box.Focus()
})

[void]$form.ShowDialog()
